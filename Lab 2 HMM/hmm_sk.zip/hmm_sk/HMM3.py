import math
import sys

def main():
    # Read in the data
    data = sys.stdin.readlines()
    # Parse the data A, B and pi
    A = parse_matrix(data[0])
    B = parse_matrix(data[1])
    pi = parse_matrix(data[2])
    #read in the observations
    observations = data[3].split()
    O = []
    #convert the observations to integers
    for i in range(1,len(observations)):
        O.append(int(observations[i]))

    a_new,b_new,  pi_new = baum_welch(A, B, pi, O)
    print(matrix_to_string(a_new))
    print(matrix_to_string(b_new))





def matrix_to_string(matrix):
    # Convert the matrix to a string
    result = ""
    result += str(len(matrix)) + " " + str(len(matrix[0])) + " "
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            result += str(round(matrix[i][j],6)) + " "
        result += ""
    return result


def parse_matrix(line):
    # first value rows, second value columns

    values_list = []
    # split the line into the values
    values = line.split()
    #first value is rows
    rows = int(values[0])
    #second value is columns
    columns = int(values[1])
    #the rest of the values are the matrix values
    for i in range(2, len(values)):
        values_list.append(float(values[i]))
    matrix = []
    for i in range(rows):
        rows_m = []
        for j in range(columns):
            rows_m.append(values_list[i*columns + j])
        matrix.append(rows_m)
    return matrix

def alpha_pass(A, B, pi, O):
    # Initialize the alpha matrix
    alpha = []
    c = [0]
    temp = []
    for i in range(len(A)):
        temp.append(0)
    for i in range(len(O)):
        alpha.append(temp[:])
    # Initialize the first column of the alpha matrix
    for i in range(len(A)):
        alpha[0][i] = pi[0][i] * B[i][O[0]]
        c[0] += alpha[0][i]
    # Scale the first column of alpha
    c[0] = 1/c[0]
    for i in range(len(A)):
        alpha[0][i] *= c[0]
    # Run the alpha pass
    for t in range(1, len(O)):
        c.append(0)
        for i in range(len(A)):
            alpha[t][i] = 0
            for j in range(len(A)):
                alpha[t][i] += alpha[t-1][j] * A[j][i]
            alpha[t][i] *= B[i][O[t]]
            c[t] += alpha[t][i]
        # Scale alpha[t][i]
        c[t] = 1/c[t]
        for i in range(len(A)):
            alpha[t][i] *= c[t]

    return alpha, c

def beta_pass(A, B, pi, O, c):
    # Initialize the beta matrix
    beta = []
    temp = []
    for i in range(len(A)):
        temp.append(1 / c[-1])
    beta.append(temp)
    # Run the beta pass
    for t in range(len(O)-2, -1, -1):
        temp = []
        for i in range(len(A)):
            b = 0
            for j in range(len(A)):
                b += beta[-1][j] * A[i][j] * B[j][O[t+1]]
            temp.append(b / c[t])
            # Scale beta[t][i]
        beta.append(temp)
    beta.reverse()

    return beta

def gamma_pass(t,i,A, B, pi, O, alpha, beta):
    g = 0
    if t == len(O)-1:
        for j in range(len(A)):
            g += alpha[t][j] * beta[t][j]
    else:
        for j in range(len(A)):
            g += alpha[t][i] * A[i][j] * B[j][O[t+1]] * beta[t+1][j]
    return g


def digamma_pass(t, i, j, A, B, pi, O, alpha, beta):
    if t == len(O)-1:
        d = 0
    else:
        d = alpha[t][i] * A[i][j] * B[j][O[t+1]] * beta[t+1][j]
    return d

def baum_welch(A, B, pi, O):
    # initilize alpha
    alpha, c = alpha_pass(A, B, pi, O)
    # initilize beta
    beta = beta_pass(A, B, pi, O, c)
    # initilize gamma
    gamma = []
    for t in range(len(O)):
        temp = []
        for i in range(len(A)):
            temp.append(gamma_pass(t,i,A, B, pi, O, alpha, beta))
        gamma.append(temp)
    # initilize digamma
    digamma = []
    for t in range(len(O)-1):
        temp = []
        for i in range(len(A)):
            temp2 = []
            for j in range(len(A)):
                temp2.append(digamma_pass(t, i, j, A, B, pi, O, alpha, beta))
            temp.append(temp2)
        digamma.append(temp)


    # Re-estimate A
    for i in range(len(A)):
        for j in range(len(A)):
            numer = 0
            denom = 0
            for t in range(len(O)-1):
                numer += digamma[t][i][j]
                denom += gamma[t][i]
            A[i][j] = numer/denom
    # Re-estimate B
    for i in range(len(B)):
        for j in range(len(B[0])):
            numer = 0
            denom = 0
            for t in range(len(O)):
                if O[t] == j:
                    numer += gamma[t][i]
                denom += gamma[t][i]
            B[i][j] = numer/denom
    # Re-estimate pi
    for i in range(len(pi)):
        pi[0][i] = gamma[0][i]

    return A, B, pi






if __name__ == "__main__":
    main()







